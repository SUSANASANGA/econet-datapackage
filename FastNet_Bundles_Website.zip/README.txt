FastNet Bundles website

Files:
- index.html: website structure and JavaScript interactions
- style.css: website styling

How to use:
1. Extract the ZIP file.
2. Open index.html in a browser, or upload both files to your web hosting.

Important:
The current Confirm Payment button only displays a message in the browser. It does NOT send a real EcoCash payment request or verify payment. A secure payment integration and backend are required for real transactions.
