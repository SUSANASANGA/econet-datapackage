EcoCash Data Bundles website

Included files:
- index.html — page structure
- style.css — responsive styling
- script.js — bundle selection and basic phone-number validation

How to run:
1. Extract this ZIP archive.
2. Keep all three files in the same folder.
3. Open index.html in a browser, or upload the files to your web host.

Payment notice:
This is a front-end demo only. It does not initiate EcoCash payments, sell data, or verify transactions. To process real purchases, integrate an authorized payment provider and a secure backend. Do not collect or store payment PINs in this page.
