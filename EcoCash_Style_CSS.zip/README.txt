EcoCash Data Bundles CSS

This ZIP contains the style.css file provided by the user.

To use it:
1. Extract the ZIP.
2. Place style.css in the same folder as your index.html.
3. Ensure your HTML includes:
   <link rel="stylesheet" href="style.css">

Note: This ZIP contains the CSS file only, not the complete website.
