const modal = document.getElementById("modal");
const selectedPlan = document.getElementById("selectedPlan");
const phoneInput = document.getElementById("phone");
const message = document.getElementById("message");

let currentPlan = "";
let currentPrice = "";

function buyBundle(plan, price) {
  currentPlan = plan;
  currentPrice = price;
  selectedPlan.textContent = `${plan} — ${price}`;
  phoneInput.value = "";
  message.textContent = "";
  message.style.color = "";
  modal.classList.add("show");
  modal.setAttribute("aria-hidden", "false");
  phoneInput.focus();
}

function closeModal() {
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
}

function confirmPurchase() {
  const phone = phoneInput.value.trim();
  const digits = phone.replace(/\D/g, "");

  if (digits.length < 9 || digits.length > 15) {
    message.style.color = "#c92a2a";
    message.textContent = "Please enter a valid phone number.";
    return;
  }

  message.style.color = "#087f5b";
  message.textContent =
    `Your selection is ${currentPlan} (${currentPrice}) for ${phone}. ` +
    "No payment has been made. Connect a verified payment provider to accept real payments.";
}

window.addEventListener("click", function (event) {
  if (event.target === modal) closeModal();
});

window.addEventListener("keydown", function (event) {
  if (event.key === "Escape") closeModal();
});
